/* Encre Libre 6.0 : lecture + véritable session membre via l'API. */

document.querySelectorAll(".read-toggle").forEach((button) => {
  button.addEventListener("click", () => {
    const id = button.getAttribute("aria-controls");
    const target = document.getElementById(id);
    const excerpt = document.getElementById(id.replace("full-", "excerpt-"));
    const expanded = button.getAttribute("aria-expanded") === "true";
    target.hidden = expanded;
    if (excerpt) excerpt.hidden = !expanded;
    button.setAttribute("aria-expanded", String(!expanded));
    button.querySelector(".toggle-label").textContent = expanded ? "Lire le texte entier" : "Refermer le texte";
    button.querySelector(".toggle-mark").textContent = expanded ? "+" : "−";
  });
});

const $ = (id) => document.getElementById(id);
const sessionStatus = $("sessionStatus");
const accountPanel = $("accountPanel");

function message(id, text) { const el = $(id); if (el) el.textContent = text; }

function renderUser(user) {
  if (!user) {
    sessionStatus.textContent = "";
    accountPanel.hidden = true;
    accountPanel.innerHTML = "";
    return;
  }
  sessionStatus.textContent = `Connecté en tant que ${user.username}.`;
  accountPanel.hidden = false;
  accountPanel.innerHTML = `<strong>${escapeHtml(user.username)}</strong><br><span>${escapeHtml(user.email)}</span><br><button class="button secondary" id="logoutButton" type="button">Se déconnecter</button>`;
  $("logoutButton").addEventListener("click", logout);
}

function escapeHtml(value) {
  return String(value).replace(/[&<>'"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;",'"':"&quot;"}[c]));
}

async function api(path, options = {}) {
  const response = await fetch(path, { credentials: "same-origin", ...options, headers: { "Content-Type": "application/json", ...(options.headers || {}) } });
  let data = {};
  try { data = await response.json(); } catch {}
  return { response, data };
}

const registerForm = $("registerForm");
if (registerForm) registerForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  message("registerMessage", "Création du compte…");
  const { response, data } = await api("/api/register", {
    method: "POST",
    body: JSON.stringify({
      username: $("registerName").value.trim(),
      email: $("registerEmail").value.trim(),
      password: $("registerPassword").value
    })
  });
  if (response.ok) {
    message("registerMessage", `Compte créé. Bienvenue, ${data.user.username}.`);
    registerForm.reset();
    renderUser(data.user);
    location.hash = "connexion";
  } else {
    const errors = { invalid_username: "Pseudo invalide (3 à 40 caractères).", invalid_email: "Adresse e-mail invalide.", invalid_password: "Le mot de passe doit comporter au moins 12 caractères.", account_creation_failed: "Impossible de créer le compte. Le pseudo ou l'adresse e-mail est peut-être déjà utilisé.", database_not_configured: "La base de données n'est pas encore configurée." };
    message("registerMessage", errors[data.error] || "Impossible de créer le compte.");
  }
});

const loginForm = $("loginForm");
if (loginForm) loginForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  message("loginMessage", "Connexion…");
  const { response, data } = await api("/api/login", { method: "POST", body: JSON.stringify({ email: $("loginEmail").value.trim(), password: $("loginPassword").value }) });
  if (response.ok) {
    message("loginMessage", `Bienvenue, ${data.user.username}.`);
    loginForm.reset();
    renderUser(data.user);
  } else {
    message("loginMessage", data.error === "database_not_configured" ? "La base de données n'est pas encore configurée." : "Adresse e-mail ou mot de passe incorrect.");
  }
});

async function logout() {
  const { response } = await api("/api/logout", { method: "POST", body: "{}" });
  if (response.ok) { message("loginMessage", "Vous êtes déconnecté."); renderUser(null); }
}

const forgot = $("forgotPassword");
if (forgot) forgot.addEventListener("click", async () => {
  const email = $("loginEmail").value.trim();
  if (!email) { message("loginMessage", "Saisissez d'abord votre adresse e-mail."); return; }
  message("loginMessage", "Demande de récupération enregistrée. L'envoi d'e-mails sera activé avec la configuration du service de messagerie.");
  await api("/api/forgot-password", { method: "POST", body: JSON.stringify({ email }) });
});

(async () => {
  try {
    const { data } = await api("/api/me", { headers: { "Content-Type": "application/json" } });
    renderUser(data.authenticated ? data.user : null);
  } catch { /* Le site reste lisible même si l'API n'est pas encore déployée. */ }
})();
