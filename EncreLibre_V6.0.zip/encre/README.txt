Encre Libre — Version 6.0
==========================

Base : V5.2.

V6.0 transforme la démonstration locale de comptes en véritable espace membre :
- inscription via Pages Functions + D1 ;
- mots de passe dérivés avec PBKDF2-SHA-256 ;
- connexion et déconnexion avec sessions serveur ;
- cookie de session HttpOnly, Secure, SameSite=Lax ;
- endpoint /api/me pour restaurer la session ;
- suppression de l'ancien stockage local des mots de passe ;
- préparation de la récupération de mot de passe sans inventer un service d'e-mail ;
- interface membre affichant l'état de connexion ;
- textes éditoriaux et identité visuelle de la V5.2 conservés.

Déploiement :
1. Créer une base Cloudflare D1 nommée encre-libre-db.
2. Exécuter schema.sql dans cette base.
3. Remplacer DATABASE_ID dans wrangler.toml par l'ID réel de la base.
4. Déployer le dossier comme projet Cloudflare Pages/Pages Functions.
5. Vérifier /api/health puis créer un compte depuis le site.

Important : la récupération de mot de passe nécessite encore un fournisseur d'e-mail
(transactionnel) pour envoyer réellement le lien à l'utilisateur. V6.0 ne prétend
pas avoir cette capacité tant qu'aucun fournisseur n'est configuré.

Le projet ne comporte aucune publicité ni paiement et ne nécessite aucun service
payant pour son code. Cloudflare peut toutefois appliquer ses propres limites et
conditions au compte d'hébergement utilisé pour le déploiement.
