import { json, sessionCookie, validateOrigin, hashPassword, hex, safeEmail } from "./_auth.js";

export async function onRequestPost({ request, env }) {
  if (!env.DB) return json({ ok: false, error: "database_not_configured" }, 503);
  if (!validateOrigin(request)) return json({ ok: false, error: "invalid_origin" }, 403);
  let body;
  try { body = await request.json(); } catch { return json({ ok: false, error: "invalid_json" }, 400); }
  const email = safeEmail(body.email);
  const password = String(body.password || "");
  if (!email || !password) return json({ ok: false, error: "invalid_credentials" }, 400);

  const user = await env.DB.prepare(`SELECT id, username, email, password_hash, password_salt FROM users WHERE email = ?`).bind(email).first();
  if (!user) return json({ ok: false, error: "invalid_credentials" }, 401);
  const saltBytes = new Uint8Array(user.password_salt.match(/.{2}/g).map(x => parseInt(x, 16)));
  const hash = await hashPassword(password, saltBytes);
  if (hash !== user.password_hash) return json({ ok: false, error: "invalid_credentials" }, 401);

  const sessionId = crypto.randomUUID();
  const expires = Math.floor(Date.now() / 1000) + 30 * 86400;
  await env.DB.prepare(`INSERT INTO sessions (id, user_id, expires_at) VALUES (?, ?, ?)`).bind(sessionId, user.id, expires).run();
  await env.DB.prepare(`DELETE FROM sessions WHERE expires_at <= ?`).bind(Math.floor(Date.now() / 1000)).run();

  return json({ ok: true, user: { id: user.id, username: user.username, email: user.email } }, 200, { "Set-Cookie": sessionCookie(sessionId) });
}
