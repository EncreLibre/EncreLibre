import { json, validateOrigin, safeEmail } from "./_auth.js";

export async function onRequestPost({ request, env }) {
  if (!env.DB) return json({ ok: false, error: "database_not_configured" }, 503);
  if (!validateOrigin(request)) return json({ ok: false, error: "invalid_origin" }, 403);
  let body;
  try { body = await request.json(); } catch { return json({ ok: false, error: "invalid_json" }, 400); }
  const email = safeEmail(body.email);
  if (!email) return json({ ok: false, error: "invalid_email" }, 400);

  // Deliberately do not expose whether the account exists.
  // Actual e-mail delivery will be enabled once a transactional mail provider is configured.
  await env.DB.prepare(`SELECT id FROM users WHERE email = ?`).bind(email).first();
  return json({ ok: true, message: "If an account exists, a password-reset message can be sent once e-mail delivery is configured." });
}
