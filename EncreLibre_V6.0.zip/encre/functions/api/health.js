export async function onRequestGet({ env }) {
  if (!env.DB) return Response.json({ ok: false, database: false }, { status: 503 });
  try {
    await env.DB.prepare("SELECT 1 AS ok").first();
    return Response.json({ ok: true, database: true });
  } catch {
    return Response.json({ ok: false, database: false }, { status: 503 });
  }
}
