import { json, getSessionId, clearSessionCookie, validateOrigin } from "./_auth.js";
export async function onRequestPost({ request, env }) {
  if (!validateOrigin(request)) return json({ ok: false, error: "invalid_origin" }, 403);
  const sid = getSessionId(request);
  if (sid && env.DB) await env.DB.prepare(`DELETE FROM sessions WHERE id = ?`).bind(sid).run();
  return json({ ok: true }, 200, { "Set-Cookie": clearSessionCookie() });
}
