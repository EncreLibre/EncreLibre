import { json, sessionCookie, validateOrigin, hashPassword, hex, safeUsername, safeEmail } from "./_auth.js";

export async function onRequestPost({ request, env }) {
  if (!env.DB) return json({ ok: false, error: "database_not_configured" }, 503);
  if (!validateOrigin(request)) return json({ ok: false, error: "invalid_origin" }, 403);

  let body;
  try { body = await request.json(); } catch { return json({ ok: false, error: "invalid_json" }, 400); }

  const username = safeUsername(body.username);
  const email = safeEmail(body.email);
  const password = String(body.password || "");
  if (!username) return json({ ok: false, error: "invalid_username" }, 400);
  if (!email) return json({ ok: false, error: "invalid_email" }, 400);
  if (password.length < 12 || password.length > 200) return json({ ok: false, error: "invalid_password" }, 400);

  const saltBytes = crypto.getRandomValues(new Uint8Array(16));
  const salt = hex(saltBytes);
  const passwordHash = await hashPassword(password, saltBytes);
  const userId = crypto.randomUUID();
  const sessionId = crypto.randomUUID();
  const expires = Math.floor(Date.now() / 1000) + 30 * 86400;

  try {
    await env.DB.prepare(`INSERT INTO users (id, username, email, password_hash, password_salt) VALUES (?, ?, ?, ?, ?)`)
      .bind(userId, username, email, passwordHash, salt).run();
    await env.DB.prepare(`INSERT INTO sessions (id, user_id, expires_at) VALUES (?, ?, ?)`)
      .bind(sessionId, userId, expires).run();
  } catch {
    return json({ ok: false, error: "account_creation_failed" }, 409);
  }

  return json({ ok: true, user: { id: userId, username, email } }, 201, { "Set-Cookie": sessionCookie(sessionId) });
}
