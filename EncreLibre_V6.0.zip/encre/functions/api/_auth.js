const SESSION_COOKIE = "encre_session";
const SESSION_DAYS = 30;

export function json(data, status = 200, headers = {}) {
  return Response.json(data, { status, headers });
}

export function cookie(name, value, options = {}) {
  const parts = [`${name}=${value}`];
  if (options.maxAge !== undefined) parts.push(`Max-Age=${options.maxAge}`);
  if (options.path) parts.push(`Path=${options.path}`);
  if (options.httpOnly) parts.push("HttpOnly");
  if (options.secure) parts.push("Secure");
  if (options.sameSite) parts.push(`SameSite=${options.sameSite}`);
  return parts.join("; ");
}

export function sessionCookie(id) {
  return cookie(SESSION_COOKIE, id, { maxAge: SESSION_DAYS * 86400, path: "/", httpOnly: true, secure: true, sameSite: "Lax" });
}

export function clearSessionCookie() {
  return cookie(SESSION_COOKIE, "", { maxAge: 0, path: "/", httpOnly: true, secure: true, sameSite: "Lax" });
}

export function getSessionId(request) {
  const raw = request.headers.get("Cookie") || "";
  const match = raw.match(new RegExp(`(?:^|;\\s*)${SESSION_COOKIE}=([^;]+)`));
  return match ? decodeURIComponent(match[1]) : null;
}

export async function currentUser(request, env) {
  if (!env.DB) return null;
  const sid = getSessionId(request);
  if (!sid) return null;
  const now = Math.floor(Date.now() / 1000);
  const row = await env.DB.prepare(`
    SELECT u.id, u.username, u.email
    FROM sessions s JOIN users u ON u.id = s.user_id
    WHERE s.id = ? AND s.expires_at > ?
  `).bind(sid, now).first();
  return row || null;
}

export function validateOrigin(request) {
  const origin = request.headers.get("Origin");
  if (!origin) return true;
  const url = new URL(request.url);
  return origin === url.origin;
}

export async function hashPassword(password, saltBytes) {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", salt: saltBytes, iterations: 100000, hash: "SHA-256" }, key, 256);
  return [...new Uint8Array(bits)].map(b => b.toString(16).padStart(2, "0")).join("");
}

export function hex(bytes) {
  return [...bytes].map(b => b.toString(16).padStart(2, "0")).join("");
}

export function safeUsername(value) {
  const username = String(value || "").trim();
  return /^[\p{L}\p{N}._-]{3,40}$/u.test(username) ? username : null;
}

export function safeEmail(value) {
  const email = String(value || "").trim().toLowerCase();
  return email.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ? email : null;
}
